from distutils.core import setup

setup(
    name='mp3',
    version='1.0',
    packages=[''],
    url='',
    license='',
    author='jake',
    author_email='omonoid@gmail.com',
    description='scrapes link and converts to mp3'
)
